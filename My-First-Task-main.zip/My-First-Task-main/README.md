In first task,I write "Speech-to-text" that represents how to make your voice to text in the Arabic language , also I Write a simple Setup code by using C++ language for WESOM ESP32 MINI.

في Speech-to-Text ،كتبت الكود البرمجي بإستخدام لغة البايثون .يتم من خلاله تحويل الصوت الى نص كتابي ،إضافة إلى أنه يدعم اللغة العربية .
وقبل تشغيل الكود البرمجي لا بد من استدعاء احدى مكتبات قوقل وهي مكتبة gtts لتمييز اللغات، وأيضا استدعاء مكتبة speechrecognition لتمييز ما إذا كان يوجد صوت أو لا .
وفيWESOM ESP32 SETUP ،كتبت الكود البرمجي البسيط بلغة C++ لتشغيل شريحة الانترنت . 







المراجع :
1- https://youtu.be/NL9M71TnFSc

2- https://youtu.be/4dd9braoqb8
